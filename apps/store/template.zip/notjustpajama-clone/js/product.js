/* ═══════════════════════════════════════════════════════════════
   Product page — gallery with zoom, variants, embroidery
   personalisation, accordions, sticky ATC, reviews, related.
   Requires shared.js.
   ═══════════════════════════════════════════════════════════════ */
"use strict";

const qs = new URLSearchParams(location.search);
let product = window.NJP.byId(qs.get("id")) || window.NJP.PRODUCTS[0];
let pdpQty = 1;
let size = "M";
let thread = "#2c2c2c";

const THREADS = { "#2c2c2c": "Charcoal", "#a4142f": "Crimson", "#c9b48e": "Gold", "#efe6d8": "Ivory" };

if (!qs.get("id") || !window.NJP.byId(qs.get("id"))) {
  history.replaceState(null, "", "?id=" + product.id);
}

document.title = product.title + " | Not Just Pajama® — Clone Demo";
window.imgFallback($("#pdpImg"), "Silk Piece");

/* ── Gallery ─────────────────────────────────────────────────── */
const galleryImgs = [product.img1, product.img2];
let galIdx = 0;

function renderGallery() {
  const stage = $("#pdpImg");
  stage.src = galleryImgs[galIdx];
  $$("#pdpThumbs .pdp-thumb").forEach((t, i) => t.classList.toggle("is-active", i === galIdx));
}
(() => {
  const thumbs = $("#pdpThumbs");
  galleryImgs.forEach((src, i) => {
    const b = document.createElement("button");
    b.className = "pdp-thumb" + (i === 0 ? " is-active" : "");
    b.innerHTML = `<img src="${src}" alt="" loading="lazy" onload="imgLoaded(this)" onerror="imgFallback(this,'Silk')">`;
    b.addEventListener("click", () => { galIdx = i; renderGallery(); });
    thumbs.appendChild(b);
  });
  $("#stagePrev").addEventListener("click", () => { galIdx = (galIdx + galleryImgs.length - 1) % galleryImgs.length; renderGallery(); });
  $("#stageNext").addEventListener("click", () => { galIdx = (galIdx + 1) % galleryImgs.length; renderGallery(); });

  /* desktop hover zoom (lens follows cursor) */
  const stage = $("#pdpStage");
  let rect = null, reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  stage.addEventListener("mouseenter", () => { rect = null; }); /* re-measure per hover (layout may have shifted) */
  stage.addEventListener("mousemove", (e) => {
    if (window.innerWidth < 980 || reduceMotion) return;
    /* gsap.quickTo-style: cache the rect once per hover, write transformOrigin
       directly (compositor-only work) instead of re-reading layout per move */
    if (!rect) rect = stage.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    $("#pdpImg").style.transformOrigin = `${x}% ${y}%`;
    $("#pdpImg").style.transform = "scale(1.9)";
    $(".pdp-zoom-hint").style.opacity = "0";
  });
  stage.addEventListener("mouseleave", () => {
    $("#pdpImg").style.transform = "";
    $(".pdp-zoom-hint").style.opacity = "";
  });
  renderGallery();
})();

/* ── Buy box basics ──────────────────────────────────────────── */
$("#pdpType").textContent = window.NJP.TYPE_LABEL[product.type] || "Silk";
$("#pdpTitle").textContent = product.title;
$("#pdpPrice").textContent = window.NJP.money(product.price);
$("#crumbHere").textContent = product.title.length > 34 ? product.title.slice(0, 34) + "…" : product.title;

if (product.was) {
  $("#pdpWas").hidden = false;
  $("#pdpWas").textContent = window.NJP.money(product.was);
  $("#pdpSave").hidden = false;
  $("#pdpSave").textContent = "Save " + window.NJP.money(product.was - product.price);
}

/* stars */
(() => {
  const full = Math.round(product.rating);
  $("#pdpStars").innerHTML = "★★★★★".slice(0, full) + '<span class="stars-off">' + "★★★★★".slice(full) + "</span>";
  $("#pdpReviews").textContent = `${product.rating.toFixed(1)} · ${product.reviews} reviews`;
})();

/* colours (demo swatch set) */
(() => {
  const swatches = {
    ivory: "#efe6d8", pink: "#e8c4c8", red: "#a4142f", blue: "#9fb4c7",
    black: "#26221e", green: "#7d8c6f", navy: "#2c3a55"
  };
  const box = $("#pdpColors");
  product.colors.forEach((c, i) => {
    const b = document.createElement("button");
    b.className = "swatch" + (i === 0 ? " is-active" : "");
    b.style.background = swatches[c] || "#ddd";
    b.title = c[0].toUpperCase() + c.slice(1);
    b.setAttribute("aria-label", "Colour " + c);
    b.addEventListener("click", () => {
      $$("#pdpColors .swatch").forEach((s) => s.classList.remove("is-active"));
      b.classList.add("is-active");
    });
    box.appendChild(b);
  });
})();

/* sizes */
$$("#pdpSizes .size").forEach((b) =>
  b.addEventListener("click", () => {
    $$("#pdpSizes .size").forEach((s) => s.classList.remove("is-active"));
    b.classList.add("is-active");
    size = b.dataset.size;
  })
);

/* size guide modal */
(() => {
  const modal = $("#sizeModal");
  const open = () => { modal.hidden = false; requestAnimationFrame(() => modal.classList.add("is-open")); document.body.style.overflow = "hidden"; };
  const close = () => {
    modal.classList.remove("is-open");
    document.body.style.overflow = "";
    setTimeout(() => { modal.hidden = true; }, 300);
  };
  $("#sizeGuideBtn").addEventListener("click", open);
  $("#sizeModalClose").addEventListener("click", close);
  modal.addEventListener("click", (e) => { if (e.target === modal) close(); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !modal.hidden) close(); });
})();

/* ── Embroidery personalisation ──────────────────────────────── */
(() => {
  const toggle = $("#embroideryToggle"), panel = $("#embroideryPanel"), input = $("#monoInput"), preview = $("#monoPreview");
  const row = $("#threadRow");
  Object.entries(THREADS).forEach(([hex, name], i) => {
    const b = document.createElement("button");
    b.className = "swatch thread" + (i === 0 ? " is-active" : "");
    b.style.background = hex;
    b.title = name;
    b.setAttribute("aria-label", "Thread colour " + name);
    b.addEventListener("click", () => {
      $$(".swatch.thread").forEach((s) => s.classList.remove("is-active"));
      b.classList.add("is-active");
      thread = hex;
    });
    row.appendChild(b);
  });
  function setOn(on) {
    toggle.setAttribute("aria-checked", String(on));
    toggle.classList.toggle("is-on", on);
    panel.hidden = !on;
  }
  toggle.addEventListener("click", () => setOn(toggle.getAttribute("aria-checked") !== "true"));
  toggle.addEventListener("keydown", (e) => { if (e.key === " " || e.key === "Enter") { e.preventDefault(); toggle.click(); } });
  input.addEventListener("input", () => {
    const v = input.value.replace(/[^a-zA-Z .&-]/g, "");
    if (v !== input.value) input.value = v;
    preview.textContent = v;
    preview.style.color = thread;
  });
})();

/* ── Qty + add to cart (with size & mono in the line id) ─────── */
$("#qtyInc").addEventListener("click", () => { pdpQty = Math.min(9, pdpQty + 1); $("#qtyVal").textContent = pdpQty; });
$("#qtyDec").addEventListener("click", () => { pdpQty = Math.max(1, pdpQty - 1); $("#qtyVal").textContent = pdpQty; });

function addCurrent() {
  const mono = $("#embroideryToggle").getAttribute("aria-checked") === "true" ? $("#monoInput").value.trim() : "";
  if ($("#embroideryToggle").getAttribute("aria-checked") === "true" && !mono) {
    window.NJP.toast("Add up to 12 characters for your embroidery");
    $("#monoInput").focus();
    return;
  }
  /* same product+different size still one demo line; include mono so
     personalised lines are distinct in the cart */
  window.NJP.Cart.add(product, { qty: pdpQty, mono: mono ? `${mono} · ${size}` : "" });
}
$("#pdpAdd").addEventListener("click", addCurrent);
$("#stickyAdd").addEventListener("click", addCurrent);

$("#pdpAddPrice").textContent = window.NJP.money(product.price);

/* wishlist */
(() => {
  const btn = $("#pdpWish");
  const sync = () => {
    const on = window.NJP.Wishlist.has(product.id);
    btn.classList.toggle("is-active", on);
    btn.querySelector("svg").setAttribute("fill", on ? "currentColor" : "none");
  };
  btn.addEventListener("click", () => {
    window.NJP.Wishlist.toggle(product.id);
    sync();
  });
  sync();
})();

/* ── Accordions ──────────────────────────────────────────────── */
/* Animate height to a measured px value (then lock it after the transition) —
   smoother and more reliable than the classic max-height hack. */
$$(".accordion .accordion-head").forEach((head) =>
  head.addEventListener("click", () => {
    const body = head.nextElementSibling;
    const open = head.getAttribute("aria-expanded") === "true";
    head.setAttribute("aria-expanded", String(!open));
    if (open) {
      body.style.height = body.scrollHeight + "px"; /* pin current height... */
      requestAnimationFrame(() => {
        body.style.height = "0";
        body.style.opacity = "0";
      });
    } else {
      body.style.height = body.scrollHeight + "px"; /* 0 -> measured height */
      body.style.opacity = "1";
      body.addEventListener("transitionend", function done(e) {
        if (e.propertyName !== "height") return;
        if (head.getAttribute("aria-expanded") === "true") body.style.height = "auto";
        body.removeEventListener("transitionend", done);
      });
    }
  })
);
$("#pdpDesc").textContent = window.NJP.descFor(product);

/* ── Sticky ATC bar ──────────────────────────────────────────── */
(() => {
  const bar = $("#pdpSticky");
  const anchor = $("#pdpAdd");
  $("#stickyImg").src = product.img1;
  $("#stickyTitle").textContent = product.title;
  $("#stickyPrice").textContent = window.NJP.money(product.price);
  window.addEventListener("scroll", () => {
    const past = anchor.getBoundingClientRect().bottom < 0;
    bar.hidden = false;
    bar.classList.toggle("is-visible", past);
  }, { passive: true });
})();

/* ── Reviews snapshot ────────────────────────────────────────── */
(() => {
  const REVIEWS = [
    ["Penelope T.", "The silk is extraordinary — cool in summer, warm in winter. The embroidery made it a gift my mother cried over.", 5],
    ["Amelia R.", "Second set I've ordered. The fit is fluid without feeling loose, and the gift box is an event in itself.", 5],
    ["Sofia M.", "Wore the robe over everything all winter — it still looks brand new after months of gentle wear.", 4]
  ];
  const grid = $("#reviewsGrid");
  REVIEWS.forEach(([name, text, stars]) => {
    const card = document.createElement("div");
    card.className = "review-card";
    card.innerHTML = `
      <p class="review-stars">${"★★★★★".slice(0, stars)}<span class="stars-off">${"★★★★★".slice(stars)}</span></p>
      <p class="review-text">“${text}”</p>
      <p class="review-name">${name} <span class="verified">Verified buyer</span></p>`;
    grid.appendChild(card);
  });
})();

/* ── Related products (same type first, then tabs) ───────────── */
(() => {
  const grid = $("#relatedGrid");
  const related = window.NJP.PRODUCTS.filter((p) => p.id !== product.id)
    .sort((a, b) => (b.type === product.type) - (a.type === product.type))
    .slice(0, 4);
  related.forEach((p) => grid.appendChild(window.NJP.productCard(p)));
})();

window.NJP.observeReveals();
