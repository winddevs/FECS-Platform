# Not Just Pajama — Full UI/UX Clone (Study Demo)

A multi-page front-end clone of [notjustpajama.com](https://www.notjustpajama.com/) —
homepage, collection page, product page and about page — built for UI/UX and
animation study. Plain HTML/CSS/vanilla JS: no build step, no frameworks, no trackers.

**Not affiliated with Not Just Pajama®.** All brand names, product names, copy and
imagery belong to their owner; images are hot-linked from the store's own CDN purely
so the demo renders, and each has a graceful fallback if it fails to load. Don't
ship this anywhere public or commercial.

## Run

Open `index.html` directly in a browser, or serve it:

```bash
cd notjustpajama-clone
python3 -m http.server 4173
# → http://localhost:4173
```

## Pages

| Page | File | What's on it |
|---|---|---|
| Home | `index.html` | Hero slider, marquee, Trending tabs, tiles, banners, Best Sellers, values, quote, Instagram, newsletter |
| Collection | `collections.html` | Full catalog with URL-driven filters, sort, pagination, view density |
| Product | `product.html?id=…` | Gallery + zoom, variants, embroidery personalisation, accordions, reviews, related |
| About | `about.html` | Story, animated counters, values, makers, press row |

## What's cloned, page by page

**Every page (injected chrome — `js/shared.js`)**
- Rotating announcement bar, centered serif logo header, hover-underline nav, hover mega menus (Shop / Gifts with promo imagery, animated caret), hide-on-scroll-down / show-on-scroll-up header with frosted-glass scroll state (backdrop-filter), active-nav marker
- Native **View Transitions API** cross-fade between pages (with a manual fade fallback for older browsers)
- 60fps discipline: everything animates `transform`/`opacity` only — tab ink uses a FLIP-style scaleX, the free-shipping bar uses scaleX, scroll handlers are rAF-throttled, images fade in on load instead of popping in
- Slide-in **cart drawer persisted in localStorage**: add / qty ± / remove, per-line embroidery note, subtotal, animated free-shipping progress bar
- Live search overlay with product results (thumbnail, name, price) as you type
- Wishlist (localStorage) with header heart link → wishlist view
- Currency selector (USD/GBP/EUR/CAD/AUD) that re-prices the whole store
- Page-transition fade, scroll-reveal animations, toast notifications, back-to-top with reading-progress ring
- Mobile: hamburger drawer with SHOP / GIFTS accordions; fully responsive to 360px

**Home** — 2-slide fullscreen hero (Ken Burns zoom, staggered copy reveal, autoplay with progress-fill dots, arrows + touch swipe) · infinite marquee · Trending Now tabs (sliding ink indicator) with product carousel (hover arrows, scroll-snap) · category tiles & editorial split banners · Best Sellers grid · brand values · serif pull-quote · Instagram strip · newsletter with validation.

**Collection** — hero band that rewrites itself from the URL (`?type=`, `?sale=1`, `?wishlist=1`, `?q=`) · sidebar filters: category radio list with counts, price buckets, colour swatches · removable active-filter chips · sort (featured / price ↑↓ / rating / A–Z) synced to the URL · 3-vs-4-column view toggle · "Load more" pagination · empty state · Recently Viewed rail.

**Product** — sticky image gallery with thumbnails, arrows and cursor-following hover zoom · star rating & review count · Sale save-strip · colour swatches · size selector with size-guide modal (animated, ESC/overlay close) · **complimentary embroidery personalisation**: toggle, 12-char input with character preview and thread-colour swatches, carried into the cart line · quantity stepper · Add-to-Cart with live price · wishlist · USP list · Description / Fabric & Care / Shipping accordions · sticky add-to-cart bar that rises when the main button scrolls away · reviews snapshot · "You May Also Love" related grid.

**About** — parallax-style hero · two-column brand story · **animated stat counters** (22 momme, 100%, 80%, +20 yrs — ease-out count-up on scroll) · core values · makers section with hover-zoom image · press row ("As seen in" — BAZAAR UK, ELLE, Vogue…) · CTA band.

## Structure

```
notjustpajama-clone/
├── index.html            # home
├── collections.html      # collection / filter page
├── product.html          # product detail page (URL-driven)
├── about.html            # brand story page
├── css/styles.css        # design system + every animation
├── js/shared.js          # chrome injection, product catalogue, cart, wishlist, search, currency
├── js/home.js            # hero slider, trending tabs, best sellers, instagram, newsletter
├── js/collection.js      # filters, sort, pagination, view toggle, recently viewed
├── js/product.js         # gallery zoom, variants, embroidery, accordions, sticky ATC
├── js/about.js           # animated counters
└── check.py              # structural self-check (tags, assets, CSS/JS consistency)
```

Typefaces: Cormorant Garamond (serif display) + Jost (sans) — free Google-font
stand-ins for the store's luxury serif/sans pairing.

## Verify

```bash
python3 check.py
```

Checks HTML tag balance on every page, local asset resolution, CSS brace balance,
class-name consistency between markup/JS and the stylesheet, `$('#id')` references
per page, and JS bracket/quote balance.
