/* ═══════════════════════════════════════════════════════════════
   About page — animated stat counters on scroll. Requires shared.js.
   ═══════════════════════════════════════════════════════════════ */
"use strict";

(() => {
  const nums = $$(".stat-num");
  if (!nums.length) return;
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const io = new IntersectionObserver((entries) => {
    entries.forEach((en) => {
      if (!en.isIntersecting) return;
      const el = en.target;
      io.unobserve(el);
      const target = parseInt(el.dataset.count, 10);
      const prefix = el.dataset.prefix || "";
      const suffix = el.dataset.suffix || "";
      if (reduce) { el.textContent = prefix + target + suffix; return; }
      const t0 = performance.now();
      const DUR = 1600;
      (function tick(now) {
        const p = Math.min(1, (now - t0) / DUR);
        const eased = 1 - Math.pow(1 - p, 3); /* ease-out cubic */
        el.textContent = prefix + Math.round(target * eased) + suffix;
        if (p < 1) requestAnimationFrame(tick);
      })(t0);
    });
  }, { threshold: 0.5 });
  nums.forEach((n) => io.observe(n));
})();
