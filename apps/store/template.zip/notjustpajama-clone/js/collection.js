/* ═══════════════════════════════════════════════════════════════
   Collection page — URL-driven filters, sort, pagination, view
   density, recently-viewed. Requires shared.js.
   ═══════════════════════════════════════════════════════════════ */
"use strict";

const state = {
  type: null, sale: false, paja: false, wishlist: false,
  colors: new Set(), price: "all", sort: "featured", view: 4,
  page: 1, perPage: 8
};

const PRICE_BUCKETS = [
  ["all", "All prices"],
  ["0-100", "Under $100"],
  ["100-200", "$100 – $200"],
  ["200-300", "$200 – $300"],
  ["300-999", "$300 +"]
];

const TYPE_TITLES = {
  pajamas: "Silk Pajamas", dresses: "Silk Dresses", robes: "Silk Robes",
  knit: "Silk Knits", accessories: "Accessories", gifts: "The Gift Shop",
  kids: "Kids", bedding: "Sleep Comforts"
};

const COLLECTION_IMGS = {
  pajamas: "https://www.notjustpajama.com/cdn/shop/files/7_84f157f3-3db3-4836-9336-4f7a099a10fc.png?v=1777448169&width=2400",
  gifts: "https://www.notjustpajama.com/cdn/shop/collections/5a1da3e287274454fb77bf77a83c053.jpg?v=1767174190&width=2400",
  robes: "https://www.notjustpajama.com/cdn/shop/files/20_db2a309f-65ec-45dc-b43f-b5aadcde0ff1.png?v=1777448160&width=2400",
  accessories: "https://www.notjustpajama.com/cdn/shop/collections/DSC03489_4d0d53c6-657f-4827-abaa-38c471bf9fd4.jpg?v=1767169163&width=2400",
  kids: "https://www.notjustpajama.com/cdn/shop/files/26112.jpg?v=1785139439&width=2400",
  bedding: "https://www.notjustpajama.com/cdn/shop/files/NJP2667B.jpg?v=1784960735&width=2400",
  knit: "https://www.notjustpajama.com/cdn/shop/files/NJP26113.jpg?v=1791527767&width=2400",
  dresses: "https://www.notjustpajama.com/cdn/shop/files/NJP26123.jpg?v=1791537037&width=2400"
};

const params = new URLSearchParams(location.search);

/* ── URL → state ─────────────────────────────────────────────── */
function readState() {
  const type = params.get("type");
  state.type = type && TYPE_TITLES[type] ? type : null;
  state.sale = params.get("sale") === "1";
  state.paja = params.get("paja") === "1";
  state.wishlist = params.get("wishlist") === "1";
  const color = params.get("color");
  if (color) color.split(",").forEach((c) => state.colors.add(c));
  const sort = params.get("sort");
  if (sort) state.sort = sort;
  const q = params.get("q");
  if (q) state.q = q.toLowerCase();
}

/* ── Filtering ───────────────────────────────────────────────── */
function pool() {
  let list = [...window.NJP.PRODUCTS];
  if (state.type) list = list.filter((p) => p.type === state.type);
  if (state.sale) list = list.filter((p) => p.was);
  if (state.paja) list = list.filter((p) => p.tab === "paja" || p.tab === "newArrivals");
  if (state.wishlist) {
    const wish = new Set(JSON.parse(localStorage.getItem("njp-wish-v1") || "[]"));
    list = list.filter((p) => wish.has(p.id));
  }
  if (state.q) list = list.filter((p) => p.title.toLowerCase().includes(state.q));
  if (state.colors.size) list = list.filter((p) => p.colors.some((c) => state.colors.has(c)));
  if (state.price !== "all") {
    const [lo, hi] = state.price.split("-").map(Number);
    list = list.filter((p) => p.price >= lo && p.price < hi);
  }
  return list;
}

function sorted(list) {
  const s = state.sort;
  if (s === "price-asc") return list.sort((a, b) => a.price - b.price);
  if (s === "price-desc") return list.sort((a, b) => b.price - a.price);
  if (s === "rating") return list.sort((a, b) => b.rating - a.rating || b.reviews - a.reviews);
  if (s === "name") return list.sort((a, b) => a.title.localeCompare(b.title));
  return list; /* featured = natural order */
}

/* ── Header copy ─────────────────────────────────────────────── */
function applyHeader() {
  let title = "All Silk Pieces", eyebrow = "The Collections";
  let desc = "Discover the full world of Not Just Pajama — silk pajamas, dresses, robes and refined home essentials, crafted from premium mulberry silk.";
  let img = COLLECTION_IMGS.pajamas;

  if (state.sale) { title = "End of Summer Sale"; eyebrow = "Up to 50% Off"; desc = "Rare moments to add silk to your rotation — reduced pieces across the collection, while they last."; img = COLLECTION_IMGS.accessories; }
  else if (state.wishlist) { title = "Your Wishlist"; eyebrow = "Saved Pieces"; desc = "The silk you have your eye on — tap a heart again to remove a piece."; img = COLLECTION_IMGS.gifts; }
  else if (state.q) { title = `Search: “${state.q}”`; eyebrow = "Results"; desc = "Pieces matching your search across the full silk universe."; }
  else if (state.paja) { title = "PAJA Apparel"; eyebrow = "The Younger Sister"; desc = "Everyday silk-knit pieces — the playful, wearable side of the house."; img = COLLECTION_IMGS.knit; }
  else if (state.type) { title = TYPE_TITLES[state.type]; eyebrow = "Shop by World"; img = COLLECTION_IMGS[state.type] || img; desc = window.NJP.descFor({ type: state.type }); }

  $("#colTitle").textContent = title;
  $("#colEyebrow").textContent = eyebrow;
  $("#colDesc").textContent = desc;
  const heroImg = $(".collection-hero img");
  if (heroImg) { heroImg.src = img; heroImg.onerror = () => window.imgFallback(heroImg, title); }
  document.title = title + " | Not Just Pajama® — Clone Demo";
}

/* ── Sidebar ─────────────────────────────────────────────────── */
function buildFilters() {
  const typeBox = $("#filterType");
  const types = [...new Set(window.NJP.PRODUCTS.map((p) => p.type))];
  types.forEach((t) => {
    const n = window.NJP.PRODUCTS.filter((p) => p.type === t).length;
    const label = document.createElement("label");
    label.className = "filter-check";
    label.innerHTML = `<input type="radio" name="ftype" value="${t}" ${state.type === t ? "checked" : ""}>
      <span class="box"></span>${window.NJP.TYPE_LABEL[t]} <em>(${n})</em>`;
    label.querySelector("input").addEventListener("change", () => {
      params.set("type", t);
      location.href = "collections.html?" + params.toString();
    });
    typeBox.appendChild(label);
  });
  const allLabel = document.createElement("label");
  allLabel.className = "filter-check";
  allLabel.innerHTML = `<input type="radio" name="ftype" value="" ${!state.type ? "checked" : ""}>
    <span class="box"></span>All pieces <em>(${window.NJP.PRODUCTS.length})</em>`;
  allLabel.querySelector("input").addEventListener("change", () => {
    params.delete("type");
    const qs = params.toString();
    location.href = "collections.html" + (qs ? "?" + qs : "");
  });
  typeBox.prepend(allLabel);

  const priceBox = $("#filterPrice");
  PRICE_BUCKETS.forEach(([val, label]) => {
    const label2 = document.createElement("label");
    label2.className = "filter-check";
    label2.innerHTML = `<input type="radio" name="fprice" value="${val}" ${state.price === val ? "checked" : ""}>
      <span class="box"></span>${label}`;
    label2.querySelector("input").addEventListener("change", () => {
      state.price = val;
      state.page = 1;
      render();
    });
    priceBox.appendChild(label2);
  });

  const colorBox = $("#filterColor");
  const swatches = {
    ivory: "#efe6d8", pink: "#e8c4c8", red: "#a4142f", blue: "#9fb4c7",
    black: "#26221e", green: "#7d8c6f", navy: "#2c3a55"
  };
  Object.entries(swatches).forEach(([name, hex]) => {
    if (!window.NJP.PRODUCTS.some((p) => p.colors.includes(name))) return;
    const b = document.createElement("button");
    b.className = "swatch" + (state.colors.has(name) ? " is-active" : "");
    b.style.background = hex;
    b.title = name[0].toUpperCase() + name.slice(1);
    b.setAttribute("aria-label", "Filter by colour " + name);
    b.addEventListener("click", () => {
      state.colors.has(name) ? state.colors.delete(name) : state.colors.add(name);
      b.classList.toggle("is-active");
      state.page = 1;
      render();
    });
    colorBox.appendChild(b);
  });
}

/* ── Chips ───────────────────────────────────────────────────── */
function renderChips() {
  const wrap = $("#activeChips");
  wrap.innerHTML = "";
  const chips = [];
  if (state.type) chips.push(["type", TYPE_TITLES[state.type]]);
  if (state.sale) chips.push(["sale", "On sale"]);
  if (state.wishlist) chips.push(["wishlist", "Wishlist"]);
  if (state.q) chips.push(["q", `“${state.q}”`]);
  state.colors.forEach((c) => chips.push(["color:" + c, c[0].toUpperCase() + c.slice(1)]));
  if (state.price !== "all") chips.push(["price", PRICE_BUCKETS.find(([v]) => v === state.price)[1]]);
  chips.forEach(([key, label]) => {
    const chip = document.createElement("button");
    chip.className = "chip";
    chip.innerHTML = `${label} <span aria-hidden="true">×</span>`;
    chip.addEventListener("click", () => {
      if (key.startsWith("color:")) state.colors.delete(key.slice(6));
      else if (key === "price") state.price = "all";
      else {
        params.delete(key);
        const qs = params.toString();
        location.href = "collections.html" + (qs ? "?" + qs : "");
        return;
      }
      state.page = 1;
      render();
    });
    wrap.appendChild(chip);
  });
  wrap.style.display = chips.length ? "flex" : "none";
}

/* ── Main render ─────────────────────────────────────────────── */
let current = [];
function render() {
  applyHeader();
  renderChips();

  current = sorted(pool());
  $("#resultCount").textContent = `${current.length} piece${current.length === 1 ? "" : "s"}`;
  const grid = $("#collectionGrid");
  grid.className = "product-grid view-" + state.view;

  const shown = current.slice(0, state.page * state.perPage);
  grid.innerHTML = "";
  shown.forEach((p) => grid.appendChild(window.NJP.productCard(p)));

  $("#emptyState").hidden = current.length > 0;
  $("#loadMoreWrap").hidden = shown.length >= current.length;

  /* persist browsing history */
  if (!state.wishlist) {
    shown.slice(0, 4).forEach((p) => pushRecent(p.id));
  }
}

/* ── Recently viewed ─────────────────────────────────────────── */
function pushRecent(id) {
  let arr = [];
  try { arr = JSON.parse(localStorage.getItem("njp-recent") || "[]"); } catch (err) { arr = []; }
  arr = [id, ...arr.filter((x) => x !== id)].slice(0, 8);
  localStorage.setItem("njp-recent", JSON.stringify(arr));
  const section = $("#recentSection"), grid = $("#recentGrid");
  const list = arr.map((rid) => window.NJP.byId(rid)).filter(Boolean).filter((p) => !current.includes(p));
  if (list.length >= 2) {
    section.hidden = false;
    grid.innerHTML = "";
    list.slice(0, 4).forEach((p) => grid.appendChild(window.NJP.productCard(p)));
  }
}

/* ── Wire up toolbar ─────────────────────────────────────────── */
$("#sortSelect").value = state.sort;
$("#sortSelect").addEventListener("change", (e) => {
  state.sort = e.target.value;
  state.page = 1;
  params.set("sort", state.sort);
  history.replaceState(null, "", "collections.html?" + params.toString());
  render();
});

$("#loadMoreBtn").addEventListener("click", () => { state.page += 1; render(); });

$("#view3").addEventListener("click", () => {
  state.view = 3;
  $("#view3").classList.add("is-active");
  $("#view4").classList.remove("is-active");
  render();
});
$("#view4").addEventListener("click", () => {
  state.view = 4;
  $("#view4").classList.add("is-active");
  $("#view3").classList.remove("is-active");
  render();
});

$("#clearFilters").addEventListener("click", () => {
  state.colors.clear();
  state.price = "all";
  state.page = 1;
  $$('input[name="fprice"]', document).forEach((i) => { if (i.value === "all") i.checked = true; });
  $$("#filterColor .swatch").forEach((s) => s.classList.remove("is-active"));
  render();
});

/* mobile filter drawer */
$("#filterToggle").addEventListener("click", () => {
  const panel = $("#filtersPanel");
  const open = panel.classList.toggle("is-open");
  $("#filterToggle").setAttribute("aria-expanded", String(open));
});

readState();
buildFilters();
render();
window.NJP.observeReveals();
