/* ═══════════════════════════════════════════════════════════════
   Not Just Pajama clone — shared runtime (study/demo).
   Injects header / drawers / footer on every page, owns product
   data, cart (localStorage), wishlist, currency, toasts, reveals.
   Original design © Not Just Pajama® — not affiliated.
   ═══════════════════════════════════════════════════════════════ */
"use strict";

/* Flash guard failsafe: if anything throws before the chrome injects,
   show the page rather than leaving it hidden. */
window.addEventListener("error", () => document.documentElement.classList.remove("chrome-wait"), true);

/* ── Image fallback (global; used by every onerror handler) ──── */
window.imgFallback = function (img, label) {
  if (img.dataset.fb) return;
  img.dataset.fb = "1";
  const txt = String(label || "Silk").slice(0, 28);
  const svg =
    '<svg xmlns="http://www.w3.org/2000/svg" width="600" height="800" viewBox="0 0 600 800">' +
    '<rect width="600" height="800" fill="#ece4d6"/>' +
    '<circle cx="300" cy="360" r="56" fill="none" stroke="#c9b48e" stroke-width="2"/>' +
    '<path d="M300 328v64M268 360h64" stroke="#c9b48e" stroke-width="2"/>' +
    `<text x="300" y="470" text-anchor="middle" font-family="Georgia, serif" font-style="italic" font-size="26" fill="#8d8477">${txt}</text>` +
    '<text x="300" y="506" text-anchor="middle" font-family="Arial, sans-serif" font-size="12" letter-spacing="3" fill="#b3a893">NOT JUST PAJAMA</text>' +
    "</svg>";
  img.src = "data:image/svg+xml," + encodeURIComponent(svg);
};
/* fade images in as they arrive (kills the CDN pop-in jank) */
window.imgLoaded = function (img) { img.classList.add("is-loaded"); };

const CDN = "https://www.notjustpajama.com/cdn/shop/files/";
const COLLECTIONS_CDN = "https://www.notjustpajama.com/cdn/shop/collections/";

const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));

const CURRENCIES = {
  USD: { symbol: "$", rate: 1, label: "United States (USD $)" },
  GBP: { symbol: "£", rate: 0.79, label: "United Kingdom (GBP £)" },
  EUR: { symbol: "€", rate: 0.92, label: "European Union (EUR €)" },
  CAD: { symbol: "C$", rate: 1.37, label: "Canada (CAD $)" },
  AUD: { symbol: "A$", rate: 1.53, label: "Australia (AUD $)" }
};

function money(usd) {
  const cur = CURRENCIES[window.NJP_CUR] || CURRENCIES.USD;
  return cur.symbol + (usd * cur.rate).toFixed(2);
}

/* ── Catalogue — names & prices from the live storefront ─────── */
const TYPE_LABEL = {
  pajamas: "Silk Pajamas", dresses: "Silk Dresses", robes: "Silk Robes",
  knit: "Silk Knits", accessories: "Accessories", gifts: "Gift Sets",
  kids: "Kids", bedding: "Sleep Comforts"
};

const PRODUCTS = [
  { id: "p01", tab: "newArrivals", type: "pajamas", colors: ["ivory"], rating: 4.9, reviews: 32, title: "SILK EVER AFTER | 22 Momme Silk Pajama Set with Removable Feathers", price: 410, img1: CDN + "2138f2579893a679a0314d07ca96ea89_8e00f980-af85-4682-9a34-0ac8a77d98e3.jpg?v=1793096959&width=600", img2: CDN + "0001_000029600035.jpg?v=1793165378&width=600" },
  { id: "p02", tab: "newArrivals", type: "knit", colors: ["ivory", "pink"], rating: 4.8, reviews: 21, title: "Kiki Cat Wool Silk Knit Top and Pants", price: 270, img1: CDN + "NJP26113.jpg?v=1791527767&width=600", img2: CDN + "1_65f3d644-c944-4bed-80e6-f35b61025503.jpg?v=1791527915&width=600" },
  { id: "p03", tab: "newArrivals", type: "knit", colors: ["ivory", "pink"], rating: 4.7, reviews: 14, title: "Kiki Cat Wool Silk Knit Midi Skirt", price: 230, img1: CDN + "NJP26121_a3046ba3-520a-43f2-9f4d-89e0cc25f21f.jpg?v=1791536568&width=600", img2: CDN + "1_e448e53d-06d7-4518-a963-015f872e8cfb.jpg?v=1791536434&width=600" },
  { id: "p04", tab: "newArrivals", type: "knit", colors: ["ivory"], rating: 4.8, reviews: 11, title: "Kiki Cat Wool Silk Knit Off Shoulder Long Sleeve Top", price: 260, img1: CDN + "NJP26176.jpg?v=1791538928&width=600", img2: CDN + "1_706e26f7-85ce-4b1f-aa8b-df6b6d981ab6.jpg?v=1791538880&width=600" },
  { id: "p05", tab: "newArrivals", type: "knit", colors: ["ivory", "blue"], rating: 4.9, reviews: 18, title: "Kiki Cat Wool Silk Knit Round Neck Short Sleeve Top", price: 200, img1: CDN + "NJP26184.jpg?v=1791538425&width=600", img2: CDN + "4_2d51153d-30ed-406f-b0e0-df01e740c8a5.jpg?v=1791538620&width=600" },
  { id: "p06", tab: "newArrivals", type: "knit", colors: ["pink"], rating: 4.6, reviews: 9, title: "Pearl Kiki Cat Wool Silk Knit Lounge Separates", price: 140, img1: CDN + "NJP26118B.jpg?v=1791531323&width=600", img2: CDN + "1_c0ebc5af-0896-471f-af4f-952caeea762c.jpg?v=1791531499&width=600" },
  { id: "p07", tab: "newArrivals", type: "dresses", colors: ["ivory"], rating: 4.8, reviews: 16, title: "Kiki Cat Wool Silk Knit Short Sleeve Dress", price: 310, img1: CDN + "NJP26169.jpg?v=1791537808&width=600", img2: CDN + "7_3fdc589f-af65-4efe-b064-af7c0eff3fe6.jpg?v=1791537786&width=600" },
  { id: "p08", tab: "newArrivals", type: "knit", colors: ["ivory"], rating: 4.7, reviews: 12, title: "Kiki Cat Wool Silk Knit Square Neck Tank Top", price: 260, img1: CDN + "NJP26155.jpg?v=1791539284&width=600", img2: CDN + "8_24ce7c6c-a904-4ca8-a8c4-9b7dd2599320.jpg?v=1791539315&width=600" },
  { id: "p09", tab: "newArrivals", type: "dresses", colors: ["pink"], rating: 4.9, reviews: 24, title: "Kiki Cat Wool Silk Knit V Neck Slip Dress", price: 310, img1: CDN + "NJP26123.jpg?v=1791537037&width=600", img2: CDN + "4_882cea05-bcf7-4636-a3d7-8a800856f30c.jpg?v=1791537108&width=600" },
  { id: "p10", tab: "newArrivals", type: "pajamas", colors: ["red"], rating: 5.0, reviews: 41, title: "Farm Edit Red Turnip Print 22 Momme Silk Long-Sleeve Pajama Set", price: 360, img1: CDN + "NJP2573.jpg?v=1788414570&width=600", img2: CDN + "1_ee280143-be60-4656-a40e-e6583d2fb0d6.jpg?v=1788415324&width=600" },
  { id: "p11", tab: "newArrivals", type: "dresses", colors: ["red"], rating: 4.8, reviews: 19, title: "Farm Edit Red Turnip Print 22 Momme Silk Sleeveless Lace-Trim Dress", price: 320, img1: CDN + "NJP2674.jpg?v=1788416320&width=600", img2: CDN + "1_ab7a9c4d-d230-4c86-97ce-ee925eb0c8ee.jpg?v=1788416289&width=600" },
  { id: "p12", tab: "newArrivals", type: "robes", colors: ["red"], rating: 4.9, reviews: 23, title: "Farm Edit Red Turnip Print 22 Momme Silk Long-Sleeve Robe", price: 310, img1: CDN + "NJP2676.jpg?v=1788416906&width=600", img2: CDN + "1_a5f39214-ca69-4421-8536-fc16a7c4d7ac.jpg?v=1788417203&width=600" },

  { id: "b01", tab: "bestSellers", type: "accessories", colors: ["red", "ivory"], rating: 4.9, reviews: 66, title: "Farm Edit Red Turnip Embroidered 22 Momme Silk Eye Mask", price: 80, img1: CDN + "NJP2677.jpg?v=1788419137&width=600", img2: CDN + "1_28773cf2-cc5a-49d5-80d9-ab94a9c0539b.jpg?v=1788419182&width=600" },
  { id: "b02", tab: "bestSellers", type: "accessories", colors: ["blue", "ivory"], rating: 4.8, reviews: 38, title: "Bubbie 16 Momme Silk Twill Printed Square Scarf", price: 110, img1: CDN + "NJP2670B.jpg?v=1784960311&width=600", img2: CDN + "2_9d313d67-2c32-424f-ba7c-239c15296c36.jpg?v=1784960336&width=600" },
  { id: "b03", tab: "bestSellers", type: "bedding", colors: ["blue"], rating: 4.9, reviews: 52, title: "Bubbie 22 Momme Silk Printed Rhinestone Pom-Pom Cushion", price: 180, img1: CDN + "NJP2669A.jpg?v=1785140119&width=600", img2: CDN + "1_ff2941f0-61b0-40ee-8332-7ce500b7b946.jpg?v=1785140137&width=600" },
  { id: "b04", tab: "bestSellers", type: "gifts", colors: ["ivory"], rating: 5.0, reviews: 47, title: "Animal Lover Box | Bubbie Silk Gift Set", price: 130, img1: CDN + "2_df6cf278-1102-4389-aaa3-6b1bb5b33618.jpg?v=1784966902&width=600", img2: CDN + "1_1f36a4a6-7680-4c83-89cc-12b2dab91098.jpg?v=1784966902&width=600" },
  { id: "b05", tab: "bestSellers", type: "bedding", colors: ["blue"], rating: 4.8, reviews: 35, title: "Bubbie 22 Momme Silk Printed Rhinestone Pillowcase", price: 110, img1: CDN + "NJP2667B.jpg?v=1784960735&width=600", img2: CDN + "NJP2667B_314a831b-9316-4bb2-b14f-67b0940f4696.jpg?v=1784960787&width=600" },
  { id: "b06", tab: "bestSellers", type: "accessories", colors: ["blue"], rating: 4.7, reviews: 29, title: "Bubbie 22 Momme Silk Printed Rhinestone Scrunchie", price: 80, img1: CDN + "NJP2666B.jpg?v=1784958922&width=600", img2: CDN + "1_aea9a12a-4c94-4281-9e8c-73bbef19d7bb.jpg?v=1784958963&width=600" },
  { id: "b07", tab: "bestSellers", type: "accessories", colors: ["red"], rating: 4.8, reviews: 31, title: "Bubbie 22 Momme Silk Printed Rhinestone Pom-Pom Eye Mask", price: 80, img1: CDN + "NJP2668B_ee548e39-1ebe-4be7-baf2-83ce79d36aa2.jpg?v=1784958661&width=600", img2: CDN + "1_8d8e2086-7022-4c3e-bc08-a46f616f772e.jpg?v=1784958621&width=600" },
  { id: "b08", tab: "bestSellers", type: "robes", colors: ["blue"], rating: 4.9, reviews: 44, title: "Bubbie 22 Momme Silk Printed Long Robe", price: 360, img1: CDN + "NJP2662.jpg?v=1784958216&width=600", img2: CDN + "4_d6b117fe-8091-42b4-8422-6595f9f7a45a.jpg?v=1784958230&width=600" },

  { id: "a01", tab: "paja", type: "pajamas", colors: ["ivory"], rating: 4.8, reviews: 27, title: "French Style Silk Short Set", price: 340, img1: CDN + "NJP2613.jpg?v=1784880000&width=600", img2: CDN + "NJP2613.jpg?v=1784880000&width=600" },
  { id: "a02", tab: "paja", type: "pajamas", colors: ["black"], rating: 4.9, reviews: 58, title: "The Dream Long Silk Pajamas Set — Black", price: 351, was: 390, img1: CDN + "NJP2658.jpg?v=1784880623&width=600", img2: CDN + "2_3dc7c870-ab1a-4433-9f6d-f7404770a010.jpg?v=1784880612&width=600" },
  { id: "a03", tab: "paja", type: "pajamas", colors: ["green"], rating: 4.6, reviews: 13, title: "Silk Pumpkin Pants Bloomers Shorts", price: 119, was: 199, img1: CDN + "NJP26111.jpg?v=1784957593&width=600", img2: CDN + "1_19970b11-93ba-4fd4-bf4d-fdf655af4ae7.jpg?v=1784957642&width=600" },
  { id: "a04", tab: "paja", type: "bedding", colors: ["ivory"], rating: 4.7, reviews: 22, title: "Classic Bowknot Silk Pillowcase", price: 81, was: 90, img1: CDN + "NJP2667B.jpg?v=1784960735&width=600", img2: CDN + "NJP2667B_314a831b-9316-4bb2-b14f-67b0940f4696.jpg?v=1784960787&width=600" },
  { id: "a05", tab: "paja", type: "kids", colors: ["blue"], rating: 4.9, reviews: 17, title: "Kids Bubbie 22 Momme Silk Peter Pan Collar Short Pajama Set", price: 260, img1: CDN + "26112.jpg?v=1785139439&width=600", img2: CDN + "1_924867f4-bedd-4dec-8b64-dd6c91d8e67e.jpg?v=1785137586&width=600" },
  { id: "a06", tab: "paja", type: "pajamas", colors: ["navy"], rating: 4.8, reviews: 39, title: "Men's Essentials Silk Pajamas — French Navy", price: 304, was: 380, img1: CDN + "2659.jpg?v=1785139224&width=600", img2: CDN + "2_471978ad-0989-4c6b-b6f5-a3008146b050.jpg?v=1785139268&width=600" },
  { id: "a07", tab: "paja", type: "gifts", colors: ["pink"], rating: 4.9, reviews: 26, title: "Little Joy Gift | Tchin-Tchin Silk Gift Set", price: 180, img1: CDN + "NJP2660.jpg?v=1784957918&width=600", img2: CDN + "1_cab0c62c-db3f-4c12-8f54-1104422e8fa2.jpg?v=1784957898&width=600" },
  { id: "a08", tab: "paja", type: "pajamas", colors: ["pink"], rating: 4.8, reviews: 33, title: "Little Heart Classic Silk Pajama Long Set", price: 390, img1: CDN + "NJP2669A.jpg?v=1785140119&width=600", img2: CDN + "1_ff2941f0-61b0-40ee-8332-7ce500b7b946.jpg?v=1785140137&width=600" }
];

const byId = (id) => PRODUCTS.find((p) => p.id === id);

function descFor(p) {
  const d = {
    pajamas: "Cut from 22 momme mulberry silk with a fluid drape and piped detailing. Temperature-regulating, hypoallergenic and gentle on skin — designed to be worn far beyond the bedroom.",
    dresses: "A dress in pure mulberry silk that moves between loungewear and occasion wear. Bias-cut for an elegant drape, finished with hand-details by our Makers.",
    robes: "Wrap yourself in 22 momme mulberry silk. A generous silhouette, deep pockets and a tie belt — the layering piece that completes every silk ritual.",
    knit: "Our signature wool-silk knit: breathable, feather-light and warm without weight. Knit to keep its shape wear after wear.",
    accessories: "Pure mulberry silk, hand-finished in our own workshops. The everyday luxury that travels everywhere with you.",
    gifts: "Arrives in our premium gift box with ribbon and a handwritten card. Complimentary custom embroidery makes it truly theirs.",
    kids: "The little one's edition — same 22 momme mulberry silk, same hand-finished care, sized and styled for small dreamers. Made to order.",
    bedding: "Sleep on clouds. 22 momme mulberry silk that is kind to skin and hair, breathable in summer and cozy in winter."
  };
  return d[p.type] || d.pajamas;
}

/* ── Product card (shared by home / collection / PDP related) ── */
function productCard(p) {
  const card = document.createElement("article");
  card.className = "product-card";
  const badge = p.was ? '<span class="card-badge">Sale</span>'
    : (p.tab === "newArrivals" ? '<span class="card-badge badge-soft">New</span>' : "");
  card.innerHTML = `
    <a class="card-link" href="product.html?id=${p.id}">
      <div class="card-media">
        ${badge}
        <button class="card-wish${Wishlist.has(p.id) ? " is-active" : ""}" data-wish="${p.id}" aria-label="Add to wishlist">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M12 20s-7.5-4.6-9.3-9.3C1.4 7.2 3.6 4 7 4c2.2 0 3.8 1.2 5 3 1.2-1.8 2.8-3 5-3 3.4 0 5.6 3.2 4.3 6.7C19.5 15.4 12 20 12 20Z"/></svg>
        </button>
        <img src="${p.img1}" alt="${p.title}" loading="lazy" onload="imgLoaded(this)" onerror="imgFallback(this,'${p.title.slice(0, 24)}')">
        <img class="img-hover" src="${p.img2}" alt="" loading="lazy" aria-hidden="true" onload="imgLoaded(this)" onerror="imgFallback(this,'${p.title.slice(0, 24)}')">
        <button class="card-quick" data-add="${p.id}">Add to Cart</button>
      </div>
      <div class="card-info">
        <p class="card-cat">${TYPE_LABEL[p.type] || "Silk"}</p>
        <h3 class="card-title">${p.title}</h3>
        <p class="card-price">
          <span class="now">${money(p.price)}</span>
          ${p.was ? `<span class="was">${money(p.was)}</span><span class="save">Save ${money(p.was - p.price)}</span>` : ""}
        </p>
      </div>
    </a>`;
  return card;
}

/* ── Wishlist (localStorage) ─────────────────────────────────── */
const Wishlist = (() => {
  const KEY = "njp-wish-v1";
  const set = new Set(JSON.parse(localStorage.getItem(KEY) || "[]"));
  const save = () => localStorage.setItem(KEY, JSON.stringify([...set]));
  return {
    has: (id) => set.has(id),
    toggle: (id) => {
      set.has(id) ? set.delete(id) : set.add(id);
      save();
      return set.has(id);
    }
  };
})();

/* ── Toast ───────────────────────────────────────────────────── */
const toast = (() => {
  let el, t;
  return (msg) => {
    el = el || $("#toast");
    if (!el) return;
    el.textContent = msg;
    el.classList.add("is-visible");
    clearTimeout(t);
    t = setTimeout(() => el.classList.remove("is-visible"), 2200);
  };
})();

/* ══════════ Injected chrome (header / drawers / footer) ══════════ */
function chromeHTML() {
  return `
  <div class="announcement" aria-label="Announcements">
    <div class="announcement-track">
      <p class="announcement-slide is-active">End of Summer — Up to 50% Off</p>
      <p class="announcement-slide">Complimentary Custom Embroidery</p>
      <p class="announcement-slide">Premium Gift Box Packaging</p>
    </div>
  </div>

  <header class="site-header" id="siteHeader">
    <div class="header-inner">
      <button class="icon-btn burger" id="burgerBtn" aria-label="Open menu" aria-expanded="false">
        <span></span><span></span><span></span>
      </button>

      <nav class="main-nav" aria-label="Main navigation">
        <ul class="nav-list">
          <li class="nav-item"><a href="collections.html">BESTSELLERS</a></li>
          <li class="nav-item has-mega">
            <a href="collections.html">SHOP</a>
            <div class="mega" role="menu">
              <div class="mega-inner">
                <div class="mega-col">
                  <p class="mega-heading">WOMEN</p>
                  <a href="collections.html?type=pajamas">Long &amp; Short Sets</a>
                  <a href="collections.html?type=dresses">Silk Dresses</a>
                  <a href="collections.html?type=robes">Silk Robes</a>
                  <a href="collections.html?type=knit">Silk Knits</a>
                  <a href="collections.html?type=accessories">Accessories</a>
                  <a href="collections.html?type=bedding">Sleep Comforts</a>
                </div>
                <div class="mega-col">
                  <p class="mega-heading">MEN</p>
                  <a href="collections.html?type=pajamas">Silk Pajamas &amp; Robes</a>
                  <p class="mega-heading mega-gap">KIDS</p>
                  <a href="collections.html?type=kids">Bubbie for Kids</a>
                </div>
                <div class="mega-promos">
                  <a class="mega-promo" href="collections.html?type=pajamas">
                    <img src="${CDN}7_84f157f3-3db3-4836-9336-4f7a099a10fc.png?v=1777448169&width=540" alt="Silk Pajamas" loading="lazy" onerror="imgFallback(this,'Silk Pajamas')">
                    <span>Silk Pajamas</span>
                  </a>
                  <a class="mega-promo" href="collections.html?type=gifts">
                    <img src="${CDN}20_db2a309f-65ec-45dc-b43f-b5aadcde0ff1.png?v=1777448160&width=540" alt="Matching Gift Sets" loading="lazy" onerror="imgFallback(this,'Matching Gift Sets')">
                    <span>Matching Gift Sets</span>
                  </a>
                </div>
              </div>
            </div>
          </li>
          <li class="nav-item has-mega">
            <a href="collections.html?type=gifts">GIFTS</a>
            <div class="mega" role="menu">
              <div class="mega-inner">
                <div class="mega-col">
                  <p class="mega-heading">DISCOVER THE GIFT SHOP</p>
                  <a href="collections.html?type=gifts">Gift Sets</a>
                  <a href="collections.html?type=gifts">Matching Sets</a>
                  <a href="collections.html?type=accessories">Little &amp; Luxe</a>
                </div>
                <div class="mega-col">
                  <p class="mega-heading">BY RECIPIENT</p>
                  <a href="collections.html?type=gifts">Gifts for Her</a>
                  <a href="collections.html?type=pajamas">Gifts for Him</a>
                  <p class="mega-heading mega-gap">PERSONALISED</p>
                  <a href="product.html?id=p10">Custom Embroidery</a>
                </div>
                <div class="mega-promos">
                  <a class="mega-promo mega-promo-wide" href="collections.html?type=gifts">
                    <img src="${COLLECTIONS_CDN}5a1da3e287274454fb77bf77a83c053.jpg?v=1767174190&width=900" alt="Thoughtful silk gifts for every meaningful moment" loading="lazy" onerror="imgFallback(this,'The Gift Shop')">
                    <span>Thoughtful silk gifts for every meaningful moment</span>
                  </a>
                </div>
              </div>
            </div>
          </li>
          <li class="nav-item"><a href="collections.html?paja=1">PAJA</a></li>
          <li class="nav-item"><a href="collections.html?type=gifts">BRIDAL</a></li>
          <li class="nav-item"><a href="about.html">ABOUT</a></li>
          <li class="nav-item nav-sale"><a href="collections.html?sale=1">Sale</a></li>
        </ul>
      </nav>

      <a class="logo" href="index.html" aria-label="Not Just Pajama home">
        NOT&nbsp;JUST&nbsp;PAJAMA<sup>®</sup>
      </a>

      <div class="header-actions">
        <a class="personalize-link" href="product.html?id=p10">Personalize Your Pajamas</a>
        <button class="icon-btn" id="searchBtn" aria-label="Search">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.8-3.8"/></svg>
        </button>
        <a class="icon-btn hide-mobile" href="about.html" aria-label="Account">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4 5-5.5 8-5.5s6.5 1.5 8 5.5"/></svg>
        </a>
        <a class="icon-btn hide-mobile" href="#" aria-label="Wishlist" id="wishLink">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M12 20s-7.5-4.6-9.3-9.3C1.4 7.2 3.6 4 7 4c2.2 0 3.8 1.2 5 3 1.2-1.8 2.8-3 5-3 3.4 0 5.6 3.2 4.3 6.7C19.5 15.4 12 20 12 20Z"/></svg>
        </a>
        <button class="icon-btn cart-btn" id="cartBtn" aria-label="Open cart">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M6 7h12l1.2 13H4.8L6 7Z"/><path d="M9 9V6a3 3 0 0 1 6 0v3"/></svg>
          <span class="cart-count" id="cartCount">0</span>
        </button>
      </div>
    </div>
  </header>

  <div class="drawer-overlay" id="drawerOverlay" hidden></div>
  <aside class="mobile-drawer" id="mobileDrawer" aria-label="Mobile menu" aria-hidden="true">
    <div class="drawer-head">
      <span class="drawer-title">MENU</span>
      <button class="icon-btn" id="drawerClose" aria-label="Close menu">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M6 6l12 12M18 6 6 18"/></svg>
      </button>
    </div>
    <nav class="drawer-nav">
      <a href="collections.html">BESTSELLERS</a>
      <button class="drawer-accordion" aria-expanded="false">SHOP
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="m6 9 6 6 6-6"/></svg>
      </button>
      <div class="drawer-sub">
        <a href="collections.html?type=pajamas">Silk Pajamas</a>
        <a href="collections.html?type=dresses">Silk Dresses</a>
        <a href="collections.html?type=robes">Silk Robes</a>
        <a href="collections.html?type=knit">Silk Knits</a>
        <a href="collections.html?type=accessories">Accessories</a>
        <a href="collections.html?type=bedding">Sleep Comforts</a>
        <a href="collections.html?type=kids">Kids</a>
      </div>
      <button class="drawer-accordion" aria-expanded="false">GIFTS
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="m6 9 6 6 6-6"/></svg>
      </button>
      <div class="drawer-sub">
        <a href="collections.html?type=gifts">Gift Sets</a>
        <a href="collections.html?type=gifts">Matching Sets</a>
        <a href="product.html?id=p10">Custom Embroidery</a>
      </div>
      <a href="about.html">ABOUT</a>
      <a class="drawer-sale" href="collections.html?sale=1">Sale</a>
    </nav>
    <a class="btn btn-outline drawer-personalize" href="product.html?id=p10">Personalize Your Pajamas</a>
  </aside>

  <div class="drawer-overlay" id="cartOverlay" hidden></div>
  <aside class="cart-drawer" id="cartDrawer" aria-label="Shopping cart" aria-hidden="true">
    <div class="drawer-head">
      <span class="drawer-title">CART (<span id="cartCount2">0</span>)</span>
      <button class="icon-btn" id="cartClose" aria-label="Close cart">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M6 6l12 12M18 6 6 18"/></svg>
      </button>
    </div>
    <div class="ship-bar">
      <div class="ship-track"><div class="ship-fill" id="shipFill"></div></div>
      <p id="shipMsg">You're $200.00 away from free shipping</p>
    </div>
    <div class="cart-items" id="cartItems">
      <p class="cart-empty" id="cartEmpty">Your cart is currently empty.</p>
    </div>
    <div class="cart-foot" id="cartFoot" hidden>
      <div class="cart-subtotal"><span>Subtotal</span><span id="cartSubtotal">$0.00</span></div>
      <p class="cart-note">Shipping, taxes, and discount codes calculated at checkout.</p>
      <button class="btn btn-dark btn-wide" id="checkoutBtn">Checkout</button>
    </div>
  </aside>

  <div class="search-overlay" id="searchOverlay" aria-hidden="true">
    <button class="icon-btn search-close" id="searchClose" aria-label="Close search">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M6 6l12 12M18 6 6 18"/></svg>
    </button>
    <div class="search-box">
      <p class="eyebrow">Search</p>
      <form id="searchForm" novalidate>
        <input type="search" id="searchInput" placeholder="Search silk pajamas, robes, gifts…" aria-label="Search">
      </form>
      <div class="search-suggest">
        <p>Popular:</p>
        <a href="collections.html?type=pajamas">Silk Pajamas</a>
        <a href="collections.html?type=accessories">Eye Mask</a>
        <a href="collections.html?type=gifts">Gift Sets</a>
        <a href="product.html?id=p10">Embroidery</a>
      </div>
      <div class="search-results" id="searchResults" hidden></div>
    </div>
  </div>

  <footer class="footer">
    <div class="footer-grid">
      <div class="footer-col">
        <p class="footer-heading">Shop</p>
        <a href="collections.html?type=pajamas">Women</a><a href="collections.html?type=pajamas">Men</a>
        <a href="collections.html?type=bedding">Sleep Comforts</a><a href="collections.html?type=gifts">Bridal Edition</a>
        <a href="collections.html?type=knit">PAJA Apparel</a><a href="collections.html?sale=1">Sale</a>
      </div>
      <div class="footer-col">
        <p class="footer-heading">Gifts</p>
        <a href="collections.html?type=gifts">Gift Sets</a><a href="collections.html?type=gifts">Matching Sets</a>
        <a href="collections.html?type=gifts">Gifts for Her</a><a href="collections.html?type=gifts">Gifts for Him</a>
        <a href="product.html?id=p10">Custom Embroidery</a>
      </div>
      <div class="footer-col">
        <p class="footer-heading">About</p>
        <a href="about.html">Our Story</a><a href="about.html">Our Makers</a>
        <a href="about.html">Our Materials</a><a href="about.html">Journal</a><a href="about.html">Contact Us</a>
      </div>
      <div class="footer-col footer-social">
        <p class="footer-heading">Follow Us</p>
        <div class="social-row">
          <a href="#" aria-label="Instagram">IG</a><a href="#" aria-label="Facebook">FB</a>
          <a href="#" aria-label="YouTube">YT</a><a href="#" aria-label="Pinterest">PT</a>
          <a href="#" aria-label="TikTok">TK</a>
        </div>
        <label class="currency-label" for="currencySelect">Currency</label>
        <select class="currency-select" id="currencySelect">
          <option value="USD">United States (USD $)</option>
          <option value="GBP">United Kingdom (GBP £)</option>
          <option value="EUR">European Union (EUR €)</option>
          <option value="CAD">Canada (CAD $)</option>
          <option value="AUD">Australia (AUD $)</option>
        </select>
      </div>
    </div>
    <div class="footer-bottom">
      <p>© 2026 Not Just Pajama® — UI/UX clone built for study purposes. All imagery © Not Just Pajama.</p>
    </div>
  </footer>

  <div class="toast" id="toast" role="status"></div>

  <button class="to-top" id="toTop" aria-label="Back to top">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><circle cx="12" cy="12" r="10" class="ring-bg"/><circle cx="12" cy="12" r="10" class="ring" id="toTopRing"/><path d="M12 16V8m-4 4 4-4 4 4"/></svg>
  </button>`;
}

/* ══════════ Chrome behaviours ══════════ */
function initChrome() {
  const host = $("#site-chrome");
  if (!host) return;
  host.innerHTML = chromeHTML();
  document.documentElement.classList.remove("chrome-wait");

  /* mark active nav item */
  const here = location.pathname.split("/").pop() || "index.html";
  $$(".main-nav .nav-item > a, .drawer-nav > a").forEach((a) => {
    const href = a.getAttribute("href") || "";
    if (href.split("?")[0] === here && here !== "") a.classList.add("is-current");
  });

  /* currency */
  window.NJP_CUR = localStorage.getItem("njp-currency") || "USD";
  const sel = $("#currencySelect");
  sel.value = window.NJP_CUR;
  sel.addEventListener("change", () => {
    localStorage.setItem("njp-currency", sel.value);
    location.reload();
  });

  /* announcement rotator */
  const slides = $$(".announcement-slide");
  if (slides.length > 1) {
    let i = 0;
    setInterval(() => {
      const cur = slides[i];
      i = (i + 1) % slides.length;
      const next = slides[i];
      cur.classList.remove("is-active");
      cur.classList.add("is-leaving");
      setTimeout(() => cur.classList.remove("is-leaving"), 500);
      next.classList.add("is-active");
    }, 4000);
  }

  /* sticky header */
  const header = $("#siteHeader");
  let last = 0, lastY = -1, headerQueued = false;
  window.addEventListener("scroll", () => {
    if (headerQueued) return;
    headerQueued = true;
    requestAnimationFrame(() => {
      headerQueued = false;
      const y = window.scrollY;
      if (y === lastY) return;
      lastY = y;
      header.classList.toggle("is-scrolled", y > 10);
      if (y > 240 && y > last) header.classList.add("is-hidden");
      else header.classList.remove("is-hidden");
      last = y;
    });
  }, { passive: true });

  /* mobile drawer */
  const drawer = $("#mobileDrawer"), dOverlay = $("#drawerOverlay"), burger = $("#burgerBtn");
  const openDrawer = () => {
    dOverlay.hidden = false;
    requestAnimationFrame(() => { dOverlay.classList.add("is-open"); drawer.classList.add("is-open"); });
    drawer.setAttribute("aria-hidden", "false");
    burger.setAttribute("aria-expanded", "true");
    document.body.style.overflow = "hidden";
  };
  const closeDrawer = () => {
    dOverlay.classList.remove("is-open");
    drawer.classList.remove("is-open");
    drawer.setAttribute("aria-hidden", "true");
    burger.setAttribute("aria-expanded", "false");
    document.body.style.overflow = "";
    setTimeout(() => { dOverlay.hidden = true; }, 350);
  };
  burger.addEventListener("click", openDrawer);
  $("#drawerClose").addEventListener("click", closeDrawer);
  dOverlay.addEventListener("click", closeDrawer);
  $$(".drawer-accordion").forEach((btn) =>
    btn.addEventListener("click", () => {
      const ex = btn.getAttribute("aria-expanded") === "true";
      btn.setAttribute("aria-expanded", String(!ex));
    })
  );
  $$(".drawer-nav a").forEach((a) => a.addEventListener("click", closeDrawer));

  /* live search */
  const overlay = $("#searchOverlay"), input = $("#searchInput"), results = $("#searchResults");
  const openSearch = () => {
    overlay.classList.add("is-open");
    overlay.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
    setTimeout(() => input.focus(), 120);
  };
  const closeSearch = () => {
    overlay.classList.remove("is-open");
    overlay.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
  };
  $("#searchBtn").addEventListener("click", openSearch);
  $("#searchClose").addEventListener("click", closeSearch);
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeSearch(); });
  overlay.addEventListener("click", (e) => { if (e.target === overlay) closeSearch(); });
  $("#searchForm").addEventListener("submit", (e) => {
    e.preventDefault();
    runSearch(input.value);
  });
  input.addEventListener("input", () => runSearch(input.value));
  function runSearch(q) {
    const query = q.trim().toLowerCase();
    if (!query) { results.hidden = true; results.innerHTML = ""; return; }
    const hits = PRODUCTS.filter((p) => p.title.toLowerCase().includes(query) || (TYPE_LABEL[p.type] || "").toLowerCase().includes(query)).slice(0, 6);
    results.hidden = false;
    results.innerHTML = hits.length
      ? hits.map((p) => `
          <a class="search-hit" href="product.html?id=${p.id}">
            <img src="${p.img1}" alt="" onload="imgLoaded(this)" onerror="imgFallback(this,'Silk')">
            <span class="search-hit-title">${p.title}</span>
            <span class="search-hit-price">${money(p.price)}</span>
          </a>`).join("")
      : '<p class="search-none">No pieces found — try “silk”, “robe” or “gift”.</p>';
  }
  $("#wishLink").addEventListener("click", (e) => {
    e.preventDefault();
    const wishIds = JSON.parse(localStorage.getItem("njp-wish-v1") || "[]");
    if (!wishIds.length) { toast("Your wishlist is empty — tap a heart to save a piece"); return; }
    location.href = "collections.html?wishlist=1";
  });

  /* page transition fade — skipped when the browser runs a native
     View Transition (CSS cross-fade handles it; no double-fade) */
  const supportsVT = "startViewTransition" in document || CSS.supports("view-transition-name", "root");
  if (!supportsVT) document.body.classList.add("page-in");
  document.addEventListener("click", (e) => {
    if (e.defaultPrevented || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button !== 0) return;
    const a = e.target.closest('a[href$=".html"], a[href*=".html?"]');
    if (!a) return;
    const href = a.getAttribute("href");
    if (!href || href.startsWith("http") || href.startsWith("#")) return;
    e.preventDefault();
    if ("startViewTransition" in document) { location.href = href; return; } /* VT handles it */
    document.body.style.opacity = "0"; /* fallback fade-out before nav */
    setTimeout(() => { location.href = href; }, 230);
  });

  initCart();
  initReveal();
  initToTop();
  bindCardActions();
}

/* ── Global card actions: quick add + wishlist hearts ────────── */
function bindCardActions() {
  document.addEventListener("click", (e) => {
    const addBtn = e.target.closest("[data-add]");
    if (addBtn) {
      const p = byId(addBtn.dataset.add);
      if (p) {
        Cart.add(p);
        addBtn.textContent = "Added ✓";
        addBtn.classList.add("added");
        setTimeout(() => { addBtn.textContent = "Add to Cart"; addBtn.classList.remove("added"); }, 1400);
      }
      return;
    }
    const wish = e.target.closest("[data-wish]");
    if (wish) {
      const on = Wishlist.toggle(wish.dataset.wish);
      wish.classList.toggle("is-active", on);
      const svg = wish.querySelector("svg");
      if (svg) {
        svg.setAttribute("fill", on ? "currentColor" : "none");
        /* restart the pop animation on every re-add */
        if (on) { svg.style.animation = "none"; void svg.offsetWidth; svg.style.animation = ""; }
      }
      toast(on ? "Saved to wishlist" : "Removed from wishlist");
      return;
    }
    const inc = e.target.closest("[data-inc]");
    if (inc) return Cart.change(inc.dataset.inc, 1);
    const dec = e.target.closest("[data-dec]");
    if (dec) return Cart.change(dec.dataset.dec, -1);
    const rem = e.target.closest("[data-remove]");
    if (rem) return Cart.remove(rem.dataset.remove);
  });
}

/* ── Cart (localStorage-persisted) ───────────────────────────── */
function initCart() {
  Cart.render();
  $("#cartBtn").addEventListener("click", Cart.open);
  $("#cartClose").addEventListener("click", Cart.close);
  $("#cartOverlay").addEventListener("click", Cart.close);
  $("#checkoutBtn").addEventListener("click", () => toast("Demo clone — checkout is not implemented"));
}

const Cart = (() => {
  const KEY = "njp-cart-v1";
  const FREE_SHIP = 200;
  let items = new Map(); /* lineId -> {p, qty, mono} */
  try {
    (JSON.parse(localStorage.getItem(KEY) || "[]")).forEach(([lid, qty, mono]) => {
      const p = byId(String(lid).split("|")[0]);
      if (p) items.set(lid, { p, qty, mono: mono || "" });
    });
  } catch (err) { items = new Map(); }
  const save = () => localStorage.setItem(KEY, JSON.stringify([...items].map(([lid, v]) => [lid, v.qty, v.mono])));

  let els = {};
  const grab = () => {
    els = {
      drawer: $("#cartDrawer"), overlay: $("#cartOverlay"),
      count: $("#cartCount"), count2: $("#cartCount2"),
      itemsBox: $("#cartItems"), empty: $("#cartEmpty"),
      foot: $("#cartFoot"), subtotal: $("#cartSubtotal"),
      fill: $("#shipFill"), msg: $("#shipMsg")
    };
  };

  function render() {
    if (!els.drawer) grab();
    const list = [...items.entries()];
    const count = list.reduce((n, [, v]) => n + v.qty, 0);
    const subtotal = list.reduce((n, [, v]) => n + v.qty * v.p.price, 0);

    els.count.textContent = count;
    els.count2.textContent = count;
    els.count.classList.toggle("has-items", count > 0);
    els.count.classList.remove("pop");
    if (count) { void els.count.offsetWidth; els.count.classList.add("pop"); }

    els.empty.hidden = count > 0;
    els.foot.hidden = count === 0;

    $$("[data-line]", els.itemsBox).forEach((n) => { if (!items.has(n.dataset.line)) n.remove(); });
    list.forEach(([lid, v]) => {
      let line = $(`[data-line="${lid}"]`, els.itemsBox);
      if (!line) {
        line = document.createElement("div");
        line.className = "cart-line";
        line.style.opacity = "0";
        line.dataset.line = lid;
        line.innerHTML = `
          <a href="product.html?id=${v.p.id}"><img src="${v.p.img1}" alt="" onload="imgLoaded(this)" onerror="imgFallback(this,'Silk')"></a>
          <div>
            <p class="cart-line-title">${v.p.title}</p>
            <p class="cart-line-meta">${money(v.p.price)}${v.mono ? " · Embroidery: “" + v.mono + "”" : " · Complimentary gift box"}</p>
            <button class="cart-remove" data-remove="${lid}">Remove</button>
          </div>
          <div class="cart-line-col">
            <span class="cart-line-price" data-price>${money(v.p.price * v.qty)}</span>
            <span class="qty">
              <button data-dec="${lid}" aria-label="Decrease">−</button>
              <span data-qty>${v.qty}</span>
              <button data-inc="${lid}" aria-label="Increase">+</button>
            </span>
          </div>`;
        els.itemsBox.appendChild(line);
        requestAnimationFrame(() => requestAnimationFrame(() => { line.style.opacity = "1"; }));
      } else {
        line.querySelector("[data-qty]").textContent = v.qty;
        line.querySelector("[data-price]").textContent = money(v.p.price * v.qty);
      }
    });

    const left = Math.max(0, FREE_SHIP - subtotal);
    els.fill.style.transform = "scaleX(" + Math.min(1, subtotal / FREE_SHIP) + ")";
    els.msg.textContent = left > 0
      ? `You're ${money(left)} away from free shipping`
      : "Congratulations! Your order ships free 🎉";
    els.subtotal.textContent = money(subtotal);
    save();
  }

  function open() {
    if (!els.drawer) grab();
    els.overlay.hidden = false;
    requestAnimationFrame(() => { els.overlay.classList.add("is-open"); els.drawer.classList.add("is-open"); });
    els.drawer.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
  }
  function close() {
    if (!els.drawer) grab();
    els.overlay.classList.remove("is-open");
    els.drawer.classList.remove("is-open");
    els.drawer.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
    setTimeout(() => { els.overlay.hidden = true; }, 350);
  }

  function add(p, opts) {
    const mono = (opts && opts.mono ? String(opts.mono).trim().slice(0, 12) : "") || "";
    const lid = p.id + (mono ? "|" + mono : "");
    const cur = items.get(lid) || { p, qty: 0, mono };
    cur.qty += (opts && opts.qty) || 1;
    items.set(lid, cur);
    render();
    toast("Added to cart — " + p.title.slice(0, 34) + (p.title.length > 34 ? "…" : ""));
    open();
  }
  function change(lid, d) {
    const v = items.get(lid);
    if (!v) return;
    v.qty += d;
    if (v.qty <= 0) items.delete(lid);
    render();
  }
  function remove(lid) { items.delete(lid); render(); }

  return { add, change, remove, open, close, render, count: () => [...items.values()].reduce((n, v) => n + v.qty, 0) };
})();

/* ── Scroll reveal ───────────────────────────────────────────── */
const revealIO = new IntersectionObserver((entries) => {
  entries.forEach((en) => {
    if (en.isIntersecting) {
      en.target.classList.add("is-visible");
      revealIO.unobserve(en.target);
    }
  });
}, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });

function observeReveals(root) {
  $$("[data-reveal]", root || document).forEach((el) => revealIO.observe(el));
}
function initReveal() { observeReveals(document); }

/* ── Back to top ─────────────────────────────────────────────── */
function initToTop() {
  const btn = $("#toTop"), ring = $("#toTopRing");
  if (!btn) return;
  const LEN = 63;
  ring.style.strokeDashoffset = LEN;
  let queued = false;
  window.addEventListener("scroll", () => {
    if (queued) return;
    queued = true;
    requestAnimationFrame(() => {
      queued = false;
      const max = document.documentElement.scrollHeight - innerHeight;
      const p = max > 0 ? window.scrollY / max : 0;
      ring.style.strokeDashoffset = LEN * (1 - p);
      btn.classList.toggle("is-visible", window.scrollY > 700);
    });
  }, { passive: true });
  btn.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));
}

/* ── Boot ────────────────────────────────────────────────────── */
window.NJP = { PRODUCTS, byId, money, productCard, toast, Cart, Wishlist, observeReveals, TYPE_LABEL, descFor };
initChrome();
