/* ═══════════════════════════════════════════════════════════════
   Home page behaviours (clone demo). Requires shared.js.
   ═══════════════════════════════════════════════════════════════ */
"use strict";

/* ── Hero slider ─────────────────────────────────────────────── */
(() => {
  const slides = $$("[data-hero-slide]");
  const dotsWrap = $("#heroDots");
  if (!slides.length) return;
  let idx = 0, timer;
  const AUTOPLAY = 6500;

  slides.forEach((_, i) => {
    const b = document.createElement("button");
    b.setAttribute("aria-label", "Go to slide " + (i + 1));
    b.addEventListener("click", () => go(i, true));
    dotsWrap.appendChild(b);
  });
  const dots = $$("button", dotsWrap);

  function go(n, manual) {
    idx = (n + slides.length) % slides.length;
    slides.forEach((s, i) => s.classList.toggle("is-active", i === idx));
    dots.forEach((d, i) => {
      d.classList.remove("is-active");
      if (i === idx) {
        void d.offsetWidth; /* restart dot-fill animation */
        d.classList.add("is-active");
      }
    });
    if (manual) restart();
  }
  function restart() {
    clearInterval(timer);
    timer = setInterval(() => go(idx + 1), AUTOPLAY);
  }
  /* don't autoplay while the tab is hidden (battery + no wasted dot-fill loops) */
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) clearInterval(timer);
    else restart();
  });
  $("#heroPrev").addEventListener("click", () => go(idx - 1, true));
  $("#heroNext").addEventListener("click", () => go(idx + 1, true));

  let x0 = null;
  const hero = $("#hero");
  hero.addEventListener("touchstart", (e) => { x0 = e.touches[0].clientX; }, { passive: true });
  hero.addEventListener("touchend", (e) => {
    if (x0 === null) return;
    const dx = e.changedTouches[0].clientX - x0;
    if (Math.abs(dx) > 48) go(idx + (dx < 0 ? 1 : -1), true);
    x0 = null;
  }, { passive: true });

  go(0);
  restart();
})();

/* ── Trending tabs + carousel ────────────────────────────────── */
(() => {
  const row = $("#trendRow"), ink = $("#tabInk"), tabs = $$(".tab");
  if (!row) return;
  row.style.transition = "opacity .25s ease";
  function render(tab) {
    row.style.opacity = "0";
    setTimeout(() => {
      row.innerHTML = "";
      window.NJP.PRODUCTS.filter((p) => p.tab === tab).forEach((p) => row.appendChild(window.NJP.productCard(p)));
      row.scrollTo({ left: 0 });
      row.style.opacity = "1";
    }, 180);
  }
  function moveInk(btn) {
    if (!btn) return;
    /* FLIP: keep ink at left:0 width:100%, move it with transform only —
       animating left/width would trigger layout every frame. */
    const parent = ink.parentElement;
    ink.style.transform =
      "translateX(" + btn.offsetLeft + "px) scaleX(" + btn.offsetWidth / parent.offsetWidth + ")";
  }
  tabs.forEach((btn) =>
    btn.addEventListener("click", () => {
      tabs.forEach((t) => { t.classList.remove("is-active"); t.setAttribute("aria-selected", "false"); });
      btn.classList.add("is-active");
      btn.setAttribute("aria-selected", "true");
      moveInk(btn);
      render(btn.dataset.tab);
    })
  );
  $("#trendPrev").addEventListener("click", () => row.scrollBy({ left: -row.clientWidth * 0.8, behavior: "smooth" }));
  $("#trendNext").addEventListener("click", () => row.scrollBy({ left: row.clientWidth * 0.8, behavior: "smooth" }));
  window.addEventListener("resize", () => moveInk($(".tab.is-active")));
  render("newArrivals");
  requestAnimationFrame(() => moveInk($(".tab.is-active")));
})();


/* ── Quote word-by-word reveal (masked rise, transform-only) ─── */
(() => {
  const q = $("[data-quote-split]");
  if (!q) return;
  const words = q.textContent.trim().split(/\s+/);
  q.textContent = "";
  words.forEach((w, i) => {
    const wrap = document.createElement("span");
    wrap.className = "qw-wrap";
    const inner = document.createElement("span");
    inner.className = "qw";
    inner.textContent = w;
    inner.style.transitionDelay = (i * 45) + "ms";
    wrap.appendChild(inner);
    q.appendChild(wrap);
    q.appendChild(document.createTextNode(" "));
  });
  new IntersectionObserver((entries, io) => {
    entries.forEach((en) => {
      if (!en.isIntersecting) return;
      q.classList.add("is-in");
      io.disconnect();
    });
  }, { threshold: 0.35 }).observe(q);
})();

/* ── Best sellers grid ───────────────────────────────────────── */
(() => {
  const grid = $("#bestGrid");
  if (!grid) return;
  window.NJP.PRODUCTS.filter((p) => p.tab === "bestSellers").slice(0, 8)
    .forEach((p) => grid.appendChild(window.NJP.productCard(p)));
})();

/* ── Instagram grid ──────────────────────────────────────────── */
(() => {
  const grid = $("#instaGrid");
  if (!grid) return;
  const shots = [
    ["NJP2573.jpg?v=1788414570&width=600", "Farm Edit silk set"],
    ["NJP2676.jpg?v=1788416906&width=600", "Turnip print robe"],
    ["NJP2677.jpg?v=1788419137&width=600", "Embroidered eye mask"],
    ["NJP26113.jpg?v=1791527767&width=600", "Kiki Cat knit set"],
    ["NJP2662.jpg?v=1784958216&width=600", "Bubbie silk robe"],
    ["NJP26169.jpg?v=1791537808&width=600", "Kiki Cat knit dress"]
  ];
  shots.forEach(([file, alt]) => {
    const a = document.createElement("a");
    a.className = "insta-item";
    a.href = "https://www.instagram.com/notjustpajama";
    a.target = "_blank";
    a.rel = "noopener";
    a.innerHTML = `<img src="https://www.notjustpajama.com/cdn/shop/files/${file}" alt="${alt}" loading="lazy" onload="imgLoaded(this)" onerror="imgFallback(this,'@notjustpajama')">`;
    grid.appendChild(a);
  });
})();

/* ── Newsletter ──────────────────────────────────────────────── */
(() => {
  const form = $("#newsletterForm");
  if (!form) return;
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const email = $("#newsletterEmail");
    const ok = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value);
    if (!ok) {
      email.style.borderBottom = "1px solid #ff8896";
      window.NJP.toast("Please enter a valid email address");
      return;
    }
    email.style.borderBottom = "";
    email.value = "";
    window.NJP.toast("Welcome to the Silk Letter ✉️");
  });
})();
